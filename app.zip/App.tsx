import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Plus, Minus, History, BarChart2, LogOut, Trash2, PlusCircle, 
  Dumbbell, Calendar, Trophy, X, Activity, Zap,
  Target, RefreshCw, Search, Check, Cloud, Settings as SettingsIcon,
  Award, Eye, EyeOff, User as UserIcon, Tag as TagIcon, Mail, Lock, Flag,
  Edit2, CheckCircle, Send, ShieldAlert, Sparkles, AlertCircle, Coins,
  Key, ChevronRight, TrendingUp, Filter, PencilLine, Hash, Scale, ChevronDown, ChevronUp, Star,
  Layers 
} from 'lucide-react';
import { Language, User, WorkoutSession, Exercise, ExerciseDefinition, Goal, GoalType, BodyweightMode, WeightEntry } from './types';
import { translations } from './translations';
import { db } from './services/db';
import { supabase, syncWorkoutsToCloud, fetchWorkoutsFromCloud, syncGoalsToCloud, fetchGoalsFromCloud } from './services/supabase';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ComposedChart, Area, Bar } from 'recharts';

const KG_TO_LBS = 2.20462;
const BODY_PARTS = ['subChest', 'subShoulder', 'subBack', 'subArms', 'subLegs', 'subCore'];
const EQUIPMENT_TAGS = ['tagBarbell', 'tagDumbbell', 'tagMachine', 'tagCable', 'tagBodyweight', 'tagPyramid'];

const DEFAULT_EXERCISES: ExerciseDefinition[] = [
  // Chest
  { id: 'bp_barbell', name: { en: 'Barbell Bench Press', cn: '杠铃平板卧推' }, bodyPart: 'subChest', tags: ['tagBarbell'] },
  { id: 'bp_incline_barbell', name: { en: 'Incline Barbell Bench Press', cn: '杠铃上斜卧推' }, bodyPart: 'subChest', tags: ['tagBarbell'] },
  { id: 'bp_dumbbell', name: { en: 'Dumbbell Bench Press', cn: '哑铃平板卧推' }, bodyPart: 'subChest', tags: ['tagDumbbell'] },
  { id: 'bp_incline_dumbbell', name: { en: 'Incline Dumbbell Bench Press', cn: '哑铃上斜卧推' }, bodyPart: 'subChest', tags: ['tagDumbbell'] },
  { id: 'fly_cable', name: { en: 'Cable Fly', cn: '绳索夹胸' }, bodyPart: 'subChest', tags: ['tagCable'] },
  { id: 'press_machine_chest', name: { en: 'Machine Chest Press', cn: '器械推胸' }, bodyPart: 'subChest', tags: ['tagMachine'] },
  { id: 'chest_dip', name: { en: 'Chest Dip', cn: '胸部双杠臂屈伸' }, bodyPart: 'subChest', tags: ['tagBodyweight'] },
  { id: 'pushup', name: { en: 'Pushup', cn: '俯撑撑' }, bodyPart: 'subChest', tags: ['tagBodyweight'] },
  
  // Back
  { id: 'dl_barbell', name: { en: 'Deadlift', cn: '硬拉' }, bodyPart: 'subBack', tags: ['tagBarbell'] },
  { id: 'row_barbell', name: { en: 'Barbell Row', cn: '杠铃划船' }, bodyPart: 'subBack', tags: ['tagBarbell'] },
  { id: 'lat_pulldown', name: { en: 'Lat Pulldown', cn: '高位下拉' }, bodyPart: 'subBack', tags: ['tagMachine', 'tagCable'] },
  { id: 'row_seated_cable', name: { en: 'Seated Cable Row', cn: '坐姿划船' }, bodyPart: 'subBack', tags: ['tagCable'] },
  { id: 'pu_weighted', name: { en: 'Weighted Pull-up', cn: '加重引体向上' }, bodyPart: 'subBack', tags: ['tagBodyweight'] },
  { id: 'single_arm_db_row', name: { en: 'Single Arm Dumbbell Row', cn: '哑铃单臂划船' }, bodyPart: 'subBack', tags: ['tagDumbbell'] },
  { id: 'tbar_row', name: { en: 'T-Bar Row', cn: 'T杠划船' }, bodyPart: 'subBack', tags: ['tagBarbell', 'tagMachine'] },
  { id: 'hyperextension', name: { en: 'Hyperextension', cn: '山羊挺身' }, bodyPart: 'subBack', tags: ['tagBodyweight', 'tagMachine'] },
  
  // Shoulder
  { id: 'ohp_barbell', name: { en: 'Overhead Press', cn: '杠铃推举' }, bodyPart: 'subShoulder', tags: ['tagBarbell'] },
  { id: 'ohp_dumbbell', name: { en: 'Dumbbell Shoulder Press', cn: '哑铃推肩' }, bodyPart: 'subShoulder', tags: ['tagDumbbell'] },
  { id: 'lat_raise_dumbbell', name: { en: 'Dumbbell Lateral Raise', cn: '哑铃侧平举' }, bodyPart: 'subShoulder', tags: ['tagDumbbell'] },
  { id: 'face_pull_cable', name: { en: 'Cable Face Pull', cn: '绳索面拉' }, bodyPart: 'subShoulder', tags: ['tagCable'] },
  { id: 'press_machine_shoulder', name: { en: 'Machine Shoulder Press', cn: '器械推肩' }, bodyPart: 'subShoulder', tags: ['tagMachine'] },
  { id: 'arnold_press', name: { en: 'Arnold Press', cn: '阿诺德推举' }, bodyPart: 'subShoulder', tags: ['tagDumbbell'] },
  { id: 'front_raise_db', name: { en: 'Dumbbell Front Raise', cn: '哑铃前平举' }, bodyPart: 'subShoulder', tags: ['tagDumbbell'] },
  
  // Legs
  { id: 'sq_barbell', name: { en: 'Barbell Squat', cn: '深蹲' }, bodyPart: 'subLegs', tags: ['tagBarbell'] },
  { id: 'goblet_squat', name: { en: 'Goblet Squat', cn: '高杯深蹲' }, bodyPart: 'subLegs', tags: ['tagDumbbell'] },
  { id: 'leg_press', name: { en: 'Leg Press', cn: '倒蹬/腿举' }, bodyPart: 'subLegs', tags: ['tagMachine'] },
  { id: 'leg_extension', name: { en: 'Leg Extension', cn: '腿屈伸' }, bodyPart: 'subLegs', tags: ['tagMachine'] },
  { id: 'leg_curl', name: { en: 'Leg Curl', cn: '腿弯举' }, bodyPart: 'subLegs', tags: ['tagMachine'] },
  { id: 'calf_raise', name: { en: 'Calf Raise', cn: '提踵' }, bodyPart: 'subLegs', tags: ['tagMachine', 'tagBodyweight'] },
  { id: 'lunge_dumbbell', name: { en: 'Dumbbell Lunge', cn: '哑铃箭步蹲' }, bodyPart: 'subLegs', tags: ['tagDumbbell'] },
  { id: 'romanian_deadlift', name: { en: 'Romanian Deadlift', cn: '罗马尼亚硬拉' }, bodyPart: 'subLegs', tags: ['tagBarbell', 'tagDumbbell'] },
  
  // Arms
  { id: 'cu_barbell', name: { en: 'Barbell Curl', cn: '杠铃弯举' }, bodyPart: 'subArms', tags: ['tagBarbell'] },
  { id: 'cu_dumbbell', name: { en: 'Dumbbell Curl', cn: '哑铃弯举' }, bodyPart: 'subArms', tags: ['tagDumbbell'] },
  { id: 'cu_ hammer', name: { en: 'Hammer Curl', cn: '锤式弯举' }, bodyPart: 'subArms', tags: ['tagDumbbell'] },
  { id: 'tricep_pushdown', name: { en: 'Tricep Pushdown', cn: '肱三头肌下压' }, bodyPart: 'subArms', tags: ['tagCable'] },
  { id: 'skull_crusher', name: { en: 'Skull Crusher', cn: '哑卧臂屈伸' }, bodyPart: 'subArms', tags: ['tagBarbell', 'tagDumbbell'] },
  { id: 'preacher_curl', name: { en: 'Preacher Curl', cn: '牧师凳弯举' }, bodyPart: 'subArms', tags: ['tagBarbell', 'tagMachine'] },
  { id: 'overhead_extension_db', name: { en: 'Overhead Tricep Extension', cn: '颈后臂屈伸' }, bodyPart: 'subArms', tags: ['tagDumbbell'] },
  
  // Core
  { id: 'plank', name: { en: 'Plank', cn: '平板支撑' }, bodyPart: 'subCore', tags: ['tagBodyweight'] },
  { id: 'leg_raise', name: { en: 'Hanging Leg Raise', cn: '悬垂举腿' }, bodyPart: 'subCore', tags: ['tagBodyweight'] },
  { id: 'cable_crunch', name: { en: 'Cable Crunch', cn: '绳索卷腹' }, bodyPart: 'subCore', tags: ['tagCable'] },
  { id: 'russian_twist', name: { en: 'Russian Twist', cn: '俄罗斯转体' }, bodyPart: 'subCore', tags: ['tagBodyweight', 'tagDumbbell'] },
  { id: 'ab_wheel', name: { en: 'Ab Wheel Rollout', cn: '健腹轮' }, bodyPart: 'subCore', tags: ['tagBodyweight'] },
];

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>(Language.CN);
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'new' | 'goals'>('dashboard');
  
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'error'>('idle');
  
  const [workouts, setWorkouts] = useState<WorkoutSession[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [weightEntries, setWeightEntries] = useState<WeightEntry[]>([]);
  const [unit, setUnit] = useState<'kg' | 'lbs'>('kg');
  const [selectedPRProject, setSelectedPRProject] = useState<string | null>(null);
  const [showLibrary, setShowLibrary] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [customTags, setCustomTags] = useState<{id: string, name: string, category: 'bodyPart' | 'equipment'}[]>([]);
  const [showAddTagModal, setShowAddTagModal] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagCategory, setNewTagCategory] = useState<'bodyPart' | 'equipment'>('bodyPart');

  const [isEditingTags, setIsEditingTags] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [tagToRename, setTagToRename] = useState<{ id: string, name: string } | null>(null);
  const [newTagNameInput, setNewTagNameInput] = useState('');

  const [showRenameExerciseModal, setShowRenameExerciseModal] = useState(false);
  const [exerciseToRename, setExerciseToRename] = useState<{ id: string, name: string } | null>(null);
  const [newExerciseNameInput, setNewExerciseNameInput] = useState('');

  const [customExercises, setCustomExercises] = useState<ExerciseDefinition[]>([]);
  const [exerciseOverrides, setExerciseOverrides] = useState<Record<string, Partial<ExerciseDefinition>>>({});
  const [tagRenameOverrides, setTagRenameOverrides] = useState<Record<string, string>>({});
  const [starredExercises, setStarredExercises] = useState<Record<string, number>>({});
  const [showAddExerciseModal, setShowAddExerciseModal] = useState(false);
  const [newExerciseName, setNewExerciseName] = useState('');
  const [newExerciseTags, setNewExerciseTags] = useState<string[]>([]);
  const [newExerciseBodyPart, setNewExerciseBodyPart] = useState<string>('subChest');

  const [isHistoryVisible, setIsHistoryVisible] = useState(false);

  const lastSelectionRef = useRef<string | null>(null);

  useEffect(() => {
    if (lastSelectionRef.current !== selectedPRProject) {
      setIsHistoryVisible(false);
      lastSelectionRef.current = selectedPRProject;
    }
  }, [selectedPRProject]);

  const [draggedTagId, setDraggedTagId] = useState<string | null>(null);
  const [draggedFromExId, setDraggedFromExId] = useState<string | null>(null);
  const [isDraggingOverSidebar, setIsDraggingOverSidebar] = useState(false);

  const [showWeightInput, setShowWeightInput] = useState(false);
  const [weightInputValue, setWeightInputValue] = useState('');
  const [editingWeightId, setEditingWeightId] = useState<string | null>(null);

  const formatWeight = (val: number): string => {
    const converted = unit === 'kg' ? val : val * KG_TO_LBS;
    return converted.toFixed(1);
  };
  const parseWeight = (val: number) => unit === 'kg' ? val : val / KG_TO_LBS;

  const [currentWorkout, setCurrentWorkout] = useState<Partial<WorkoutSession>>({ title: '', exercises: [], date: new Date().toISOString() });
  const [newGoal, setNewGoal] = useState<Partial<Goal>>({ type: 'weight', targetValue: 0, currentValue: 0, label: '' });

  const resolveName = (storedName: string): string => {
    const allDef = [...DEFAULT_EXERCISES, ...customExercises];
    const def = allDef.find(d => {
      const over = exerciseOverrides[d.id];
      return d.name.en === storedName || 
             d.name.cn === storedName || 
             over?.name?.en === storedName || 
             over?.name?.cn === storedName;
    });

    if (def) {
      return exerciseOverrides[def.id]?.name?.[lang] || def.name[lang];
    }
    return storedName;
  };

  const bestLifts = useMemo(() => {
    const liftsMap: Record<string, number> = {};
    workouts.forEach(session => session.exercises.forEach(ex => ex.sets.forEach(set => {
      const w = set.weight || 0;
      const normalizedName = resolveName(ex.name);
      if (!liftsMap[normalizedName] || w > liftsMap[normalizedName]) liftsMap[normalizedName] = w;
    })));

    return Object.entries(liftsMap)
      .map(([name, weight]) => ({ name, weight }))
      .sort((a, b) => {
        const starA = starredExercises[a.name] || 0;
        const starB = starredExercises[b.name] || 0;
        if (starA !== starB) return starB - starA;
        return a.name.localeCompare(b.name, lang === Language.CN ? 'zh-Hans-CN' : 'en');
      });
  }, [workouts, lang, exerciseOverrides, starredExercises]);

  const getChartDataFor = (target: string) => {
    if (target === '__WEIGHT__') {
      return weightEntries
        .map(entry => ({
          date: new Date(entry.date).toLocaleDateString(lang === Language.CN ? 'zh-CN' : 'en-US', { month: 'short', day: 'numeric' }),
          weight: Number(formatWeight(entry.weight)),
          timestamp: new Date(entry.date).getTime()
        }))
        .sort((a, b) => a.timestamp - b.timestamp);
    }
    const searchName = target.trim();
    return workouts
      .filter(w => w.exercises.some(ex => resolveName(ex.name).trim() === searchName))
      .map(w => {
        const ex = w.exercises.find(e => resolveName(e.name).trim() === searchName)!;
        const maxW = Math.max(...ex.sets.map(s => s.weight || 0));
        const sessionVolume = ex.sets.reduce((sum, set) => sum + (set.weight || 0) * (set.reps || 0), 0);
        return { 
          date: new Date(w.date).toLocaleDateString(lang === Language.CN ? 'zh-CN' : 'en-US', { month: 'short', day: 'numeric' }), 
          weight: Number(formatWeight(maxW)),
          volume: Number(formatWeight(sessionVolume)),
          timestamp: new Date(w.date).getTime() 
        };
      })
      .sort((a, b) => a.timestamp - b.timestamp);
  };

  const renderTrendChart = (target: string) => {
    const data = getChartDataFor(target);
    const isWeight = target === '__WEIGHT__';
    if (data.length === 0) return null;

    return (
      <div className="w-full h-[250px] mt-6 animate-in fade-in slide-in-from-top-2">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
            <defs>
              <linearGradient id={`grad-${target}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={isWeight ? '#818cf8' : '#3b82f6'} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={isWeight ? '#818cf8' : '#3b82f6'} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="date" stroke="#475569" fontSize={10} tickMargin={15} minTickGap={40} tick={{ fill: '#94a3b8' }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="left" stroke="#475569" fontSize={10} tick={{ fill: '#94a3b8' }} axisLine={false} tickLine={false} domain={['auto', 'auto']} />
            {!isWeight && <YAxis yAxisId="right" orientation="right" hide domain={['auto', 'auto']} />}
            <Tooltip 
              contentStyle={{ backgroundColor: '#0f172a', borderRadius: '16px', border: '1px solid #1e293b', padding: '12px' }} 
              itemStyle={{ fontWeight: '900', color: '#fff', fontSize: '12px' }}
              labelStyle={{ color: '#64748b', fontSize: '10px', marginBottom: '4px', textTransform: 'uppercase', fontWeight: 'bold' }}
              formatter={(val: number, name: string) => {
                const label = name === 'weight' ? (isWeight ? translations.currentWeight[lang] : translations.weight[lang]) : translations.trainingVolume[lang];
                return [val.toFixed(1), `${label} (${unit}${name === 'volume' ? '·reps' : ''})`];
              }}
            />
            {!isWeight && (
              <Bar 
                yAxisId="right"
                dataKey="volume" 
                fill="#3b82f6" 
                opacity={0.15}
                radius={[4, 4, 0, 0]}
                barSize={20}
                animationDuration={1500}
              />
            )}
            <Area 
              yAxisId="left"
              type="monotone" 
              dataKey="weight" 
              stroke={isWeight ? '#818cf8' : '#3b82f6'} 
              strokeWidth={4} 
              fillOpacity={1} 
              fill={`url(#grad-${target})`}
              animationDuration={1500}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    );
  };


  useEffect(() => {
    const initApp = async () => {
      await db.init();
      
      supabase.auth.onAuthStateChange(async (event, session) => {
        if (session?.user) {
          const u = { id: session.user.id, username: session.user.user_metadata?.display_name || session.user.email?.split('@')[0] || 'User', email: session.user.email! };
          setUser(u);
          localStorage.setItem('fitlog_current_user', JSON.stringify(u));
          await performFullSync(u.id);
        }
      });

      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const u = { id: session.user.id, username: session.user.user_metadata?.display_name || session.user.email?.split('@')[0] || 'User', email: session.user.email! };
        setUser(u);
        await performFullSync(u.id);
      } else {
        const savedUser = localStorage.getItem('fitlog_current_user');
        if (savedUser) {
          const u = JSON.parse(savedUser);
          setUser(u);
          await loadLocalData(u.id);
        }
      }
      const ls = (k: string) => localStorage.getItem(k);
      const savedCustomTags = ls('fitlog_custom_tags'); if (savedCustomTags) setCustomTags(JSON.parse(savedCustomTags));
      const savedCustomExercises = ls('fitlog_custom_exercises'); if (savedCustomExercises) setCustomExercises(JSON.parse(savedCustomExercises));
      const savedUnit = ls('fitlog_unit') as 'kg' | 'lbs'; if (savedUnit) setUnit(savedUnit);
      const savedLang = ls('fitlog_lang') as Language; if (savedLang) setLang(savedLang);
      const savedTagOverrides = ls('fitlog_tag_rename_overrides'); if (savedTagOverrides) setTagRenameOverrides(JSON.parse(savedTagOverrides));
      const savedExOverrides = ls('fitlog_exercise_overrides'); if (savedExOverrides) setExerciseOverrides(JSON.parse(savedExOverrides));
      const savedStarred = ls('fitlog_starred_exercises'); if (savedStarred) setStarredExercises(JSON.parse(savedStarred));
    };
    initApp();
  }, []);

  const loadLocalData = async (userId: string) => {
    const allW = await db.getAll<WorkoutSession>('workouts');
    const allG = await db.getAll<Goal>('goals');
    const allWeights = await db.getAll<WeightEntry>('weightLogs');
    const userW = allW.filter(w => w.userId === userId);
    const userG = allG.filter(g => g.userId === userId);
    const userWeights = allWeights.filter(w => w.userId === userId);

    setWorkouts(userW.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setGoals(userG);
    setWeightEntries(userWeights.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };

  const performFullSync = async (currentUserId: string) => {
    if (currentUserId === 'u_guest') return;
    setSyncStatus('syncing');
    try {
      const remoteWorkouts = await fetchWorkoutsFromCloud();
      if (remoteWorkouts) {
        for (const rw of remoteWorkouts) {
          await db.save('workouts', { id: rw.id, userId: rw.user_id, date: rw.date, title: rw.title, exercises: rw.exercises, notes: rw.notes });
        }
      }
      const localWorkouts = await db.getAll<WorkoutSession>('workouts');
      await syncWorkoutsToCloud(localWorkouts.filter(w => w.userId === currentUserId));

      const remoteGoals = await fetchGoalsFromCloud();
      if (remoteGoals) {
        for (const rg of remoteGoals) {
          await db.save('goals', { id: rg.id, userId: rg.user_id, type: rg.type, label: rg.label, target_value: rg.target_value, current_value: rg.current_value, unit: rg.unit });
        }
      }
      const localGoals = await db.getAll<Goal>('goals');
      await syncGoalsToCloud(localGoals.filter(g => g.userId === currentUserId));
      
      await loadLocalData(currentUserId);
      setSyncStatus('idle');
    } catch (e: any) {
      console.error("Sync Failure:", e.message);
      setSyncStatus('error');
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault(); setIsLoading(true); setAuthError(null);
    try {
      const res = authMode === 'register' 
        ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: 'http://localhost', data: { display_name: username } } }) 
        : await supabase.auth.signInWithPassword({ email, password });
      
      if (res.error) throw res.error;
      if (res.data.user) {
        const u = { id: res.data.user.id, username: res.data.user.user_metadata?.display_name || email.split('@')[0], email };
        setUser(u); 
        localStorage.setItem('fitlog_current_user', JSON.stringify(u)); 
        await performFullSync(u.id);
      }
    } catch (err: any) { setAuthError(err.message); } finally { setIsLoading(false); }
  };

  const handleSaveWorkout = async () => {
    if (!currentWorkout.exercises?.length || !user) return;
    const session: WorkoutSession = { ...currentWorkout, id: currentWorkout.id || Date.now().toString(), userId: user.id, title: currentWorkout.title || `Workout ${new Date().toLocaleDateString()}`, date: currentWorkout.date || new Date().toISOString() } as WorkoutSession;
    await db.save('workouts', session);
    await loadLocalData(user.id); 
    setActiveTab('dashboard'); 
    setCurrentWorkout({ title: '', exercises: [], date: new Date().toISOString() });
    if (user.id !== 'u_guest') {
      try { await syncWorkoutsToCloud([session]); } catch (err) { console.warn("Sync failed"); }
    }
  };

  const handleEditWorkout = (workoutId: string) => {
    const workoutToEdit = workouts.find(w => w.id === workoutId);
    if (workoutToEdit) {
      setCurrentWorkout({ ...workoutToEdit });
      setActiveTab('new');
      setSelectedPRProject(null);
    }
  };

  const handleAddGoal = async () => {
    if (!newGoal.label || !newGoal.targetValue || !user) return;
    const goal: Goal = { id: Date.now().toString(), userId: user.id, type: newGoal.type as GoalType, label: newGoal.label!, targetValue: newGoal.targetValue!, currentValue: newGoal.currentValue || 0, unit: newGoal.type === 'weight' ? unit : (newGoal.type === 'strength' ? unit : 'times/week') };
    await db.save('goals', goal); 
    await loadLocalData(user.id);
    setShowGoalModal(false);
    if (user.id !== 'u_guest') {
       try { await syncGoalsToCloud([goal]); } catch (err) { console.warn("Sync failed"); }
    }
  };

  const handleLogWeight = async () => {
    if (!weightInputValue || !user) return;
    const w = Number(weightInputValue);
    let dateToUse = new Date().toISOString();
    if (editingWeightId) {
      const old = weightEntries.find(we => we.id === editingWeightId);
      if (old) dateToUse = old.date;
    }
    const entry: WeightEntry = {
      id: editingWeightId || Date.now().toString(),
      userId: user.id,
      weight: parseWeight(w),
      date: dateToUse,
      unit: unit
    };
    await db.save('weightLogs', entry);
    const isLatest = weightEntries.length === 0 || new Date(dateToUse).getTime() >= new Date(weightEntries[0].date).getTime();
    if (isLatest) {
      const weightGoals = goals.filter(g => g.type === 'weight');
      for (const g of weightGoals) {
        const updatedGoal = { ...g, currentValue: w };
        await db.save('goals', updatedGoal);
      }
    }
    await loadLocalData(user.id);
    setWeightInputValue('');
    setEditingWeightId(null);
    setShowWeightInput(false);
    setSelectedPRProject('__WEIGHT__');
  };

  const triggerEditWeight = (entry: WeightEntry) => {
    setEditingWeightId(entry.id);
    const currentVal = unit === 'kg' ? entry.weight : entry.weight * KG_TO_LBS;
    setWeightInputValue(currentVal.toFixed(1).replace(/\.0$/, '')); 
    setShowWeightInput(true);
  };

  const toggleStarExercise = (name: string) => {
    setStarredExercises(prev => {
      const next = { ...prev };
      if (next[name]) delete next[name];
      else next[name] = Date.now();
      localStorage.setItem('fitlog_starred_exercises', JSON.stringify(next));
      return next;
    });
  };

  const getTagName = (tid: string) => {
    // 针对 tagPyramid 特殊处理双语显示
    if (tid === 'tagPyramid') return lang === Language.CN ? '递增/递减组' : 'Pyramid/Drop Set';
    return tagRenameOverrides[tid] || (customTags.find(ct => ct.id === tid)?.name) || (translations[tid]?.[lang] || tid);
  }

  const isBodyweightExercise = (name: string): boolean => {
    const allDef = [...DEFAULT_EXERCISES, ...customExercises];
    const def = allDef.find(d => d.name.en === name || d.name.cn === name || exerciseOverrides[d.id]?.name?.en === name || exerciseOverrides[d.id]?.name?.cn === name);
    if (!def) return false;
    const tags = exerciseOverrides[def.id]?.tags || def.tags;
    return tags.includes('tagBodyweight');
  };

  const isPyramidExercise = (name: string): boolean => {
    const allDef = [...DEFAULT_EXERCISES, ...customExercises];
    const def = allDef.find(d => d.name.en === name || d.name.cn === name || exerciseOverrides[d.id]?.name?.en === name || exerciseOverrides[d.id]?.name?.cn === name);
    if (!def) return false;
    const tags = exerciseOverrides[def.id]?.tags || def.tags;
    return tags.includes('tagPyramid');
  };

  const filteredExercises = useMemo(() => {
    const all = [...DEFAULT_EXERCISES, ...customExercises].map(ex => exerciseOverrides[ex.id] ? { ...ex, ...exerciseOverrides[ex.id] } : ex);
    return all.filter(ex => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !searchQuery || ex.name[lang].toLowerCase().includes(q) || ex.tags.some(t => getTagName(t).toLowerCase().includes(q)) || getTagName(ex.bodyPart).toLowerCase().includes(q);
      const selParts = selectedTags.filter(t => BODY_PARTS.includes(t) || customTags.some(ct => ct.id === t && ct.category === 'bodyPart'));
      const selEquips = selectedTags.filter(t => EQUIPMENT_TAGS.includes(t) || customTags.some(ct => ct.id === t && ct.category === 'equipment'));
      const matchPart = selParts.length === 0 || selParts.includes(ex.bodyPart);
      const matchEquip = selEquips.length === 0 || ex.tags.some(t => selEquips.includes(t));
      return matchSearch && matchPart && matchEquip;
    });
  }, [searchQuery, selectedTags, lang, customTags, customExercises, exerciseOverrides, tagRenameOverrides]);

  const handleRenameTag = () => {
    if (!tagToRename || !newTagNameInput) return;
    const updatedOverrides = { ...tagRenameOverrides, [tagToRename.id]: newTagNameInput };
    setTagRenameOverrides(updatedOverrides);
    localStorage.setItem('fitlog_tag_rename_overrides', JSON.stringify(updatedOverrides));
    setShowRenameModal(false) ; setTagToRename(null); setNewTagNameInput('');
  };

  const handleRenameExercise = () => {
    if (!exerciseToRename || !newExerciseNameInput) return;
    setExerciseOverrides(prev => {
        const current = prev[exerciseToRename.id] || {};
        const next = { ...current, name: { ...((current.name as any) || {}), [lang]: newExerciseNameInput } };
        const updated = { ...prev, [exerciseToRename.id]: next };
        localStorage.setItem('fitlog_exercise_overrides', JSON.stringify(updated));
        return updated;
    });
    setShowRenameExerciseModal(false); setExerciseToRename(null); setNewExerciseNameInput('');
  };

  const handleDeleteTag = (tid: string) => {
    const updatedCustom = customTags.filter(ct => ct.id !== tid);
    setCustomTags(updatedCustom); localStorage.setItem('fitlog_custom_tags', JSON.stringify(updatedCustom));
    const updatedOverrides = { ...tagRenameOverrides }; delete updatedOverrides[tid];
    setTagRenameOverrides(updatedOverrides); localStorage.setItem('fitlog_tag_rename_overrides', JSON.stringify(updatedOverrides));
  };

  const handleDropOnExercise = (e: React.DragEvent, exId: string) => {
    e.preventDefault();
    const tagId = draggedTagId; if (!tagId || draggedFromExId) return;
    const isBodyPart = BODY_PARTS.includes(tagId) || customTags.some(ct => ct.id === tagId && ct.category === 'bodyPart');
    setExerciseOverrides(prev => {
        const current = prev[exId] || {}; const baseEx = [...DEFAULT_EXERCISES, ...customExercises].find(e => e.id === exId);
        if (!baseEx) return prev;
        let next: Partial<ExerciseDefinition>;
        if (isBodyPart) next = { ...current, bodyPart: tagId };
        else { const existingTags = current.tags || baseEx.tags; if (existingTags.includes(tagId)) return prev; next = { ...current, tags: [...existingTags, tagId] }; }
        const updated = { ...prev, [exId]: next }; localStorage.setItem('fitlog_exercise_overrides', JSON.stringify(updated));
        return updated;
    });
    setDraggedTagId(null);
  };

  const handleRemoveTagFromExercise = (exId: string, tagId: string) => {
    setExerciseOverrides(prev => {
        const current = prev[exId] || {}; const baseEx = [...DEFAULT_EXERCISES, ...customExercises].find(e => e.id === exId);
        if (!baseEx) return prev;
        const existingTags = current.tags || baseEx.tags; const next = { ...current, tags: existingTags.filter(t => t !== tagId) };
        const updated = { ...prev, [exId]: next }; localStorage.setItem('fitlog_exercise_overrides', JSON.stringify(updated));
        return updated;
    });
  };

  const handleToggleLanguage = () => {
    const nextLang = lang === Language.CN ? Language.EN : Language.CN;
    if (selectedPRProject && selectedPRProject !== '__WEIGHT__') {
      const allDef = [...DEFAULT_EXERCISES, ...customExercises];
      const def = allDef.find(d => {
        const over = exerciseOverrides[d.id];
        const nameInCurrentLang = over?.name?.[lang] || d.name[lang];
        return nameInCurrentLang === selectedPRProject;
      });
      if (def) {
        const nameInNextLang = exerciseOverrides[def.id]?.name?.[nextLang] || def.name[nextLang];
        lastSelectionRef.current = nameInNextLang;
        setSelectedPRProject(nameInNextLang);
      }
    }
    setLang(nextLang);
    localStorage.setItem('fitlog_lang', nextLang);
    setShowSettings(false);
  };

  const renderSetCapsule = (s: any, si: number) => (
    <div key={s.id} className="bg-slate-900/60 border border-slate-800/80 px-4 py-2 rounded-2xl flex flex-col gap-1 transition-all hover:border-blue-500/30">
      <div className="flex items-center gap-1.5">
        <span className="font-black text-slate-100 text-sm leading-none">{formatWeight(s.weight)}</span>
        <span className="text-[10px] text-slate-500 font-bold lowercase leading-none">{unit}</span>
        <span className="text-slate-600 mx-0.5 font-black leading-none">×</span>
        <span className="font-black text-slate-100 text-sm leading-none">{s.reps}</span>
      </div>
      {s.subSets && s.subSets.length > 0 && (
        <div className="flex flex-col gap-0.5 mt-1 border-t border-slate-800/50 pt-1">
          {s.subSets.map((ss: any, ssi: number) => (
            <div key={ssi} className="flex items-center gap-1 opacity-60">
              <span className="text-[9px] font-bold text-slate-300">{formatWeight(ss.weight)}</span>
              <span className="text-[8px] text-slate-500 lowercase">×</span>
              <span className="text-[9px] font-bold text-slate-300">{ss.reps}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen pb-32 bg-slate-900 text-slate-100 font-sans selection:bg-blue-500/30">
      
      {showWeightInput && (
        <div className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-sm rounded-[2.5rem] p-8 space-y-6 shadow-2xl">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-black">{editingWeightId ? (lang === Language.CN ? '编辑体重记录' : 'Edit Weight Entry') : translations.logWeight[lang]}</h2>
                <button onClick={() => { setShowWeightInput(false); setEditingWeightId(null); setWeightInputValue(''); }}><X size={20}/></button>
              </div>
              <div className="space-y-4">
                 <div className="relative group">
                    <Scale className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500" size={24} />
                    <input type="number" step="0.1" className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-6 pl-16 pr-20 text-2xl font-black outline-none focus:ring-2 focus:ring-blue-500" value={weightInputValue} onChange={e => setWeightInputValue(e.target.value)} placeholder="0.0" autoFocus />
                    <span className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-500 font-black text-xl uppercase">{unit}</span>
                 </div>
              </div>
              <button onClick={handleLogWeight} className="w-full bg-blue-600 py-5 rounded-2xl font-black text-lg shadow-xl shadow-blue-600/20 active:scale-95 transition-all">{translations.confirm[lang]}</button>
           </div>
        </div>
      )}

      {showAddTagModal && (
        <div className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-sm rounded-[2rem] p-8 space-y-6 shadow-2xl">
              <div className="flex justify-between items-center mb-2">
                <h2 className="text-xl font-black">{translations.addCustomTag[lang]}</h2>
                <button onClick={() => setShowAddTagModal(false)}><X size={20}/></button>
              </div>
              <div className="flex gap-2 p-1 bg-slate-800 rounded-xl mb-4">
                {['bodyPart', 'equipment'].map(cat => (
                  <button key={cat} onClick={() => setNewTagCategory(cat as 'bodyPart' | 'equipment')} className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase transition-all ${newTagCategory === cat ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500'}`}>{cat === 'bodyPart' ? translations.bodyPartHeader[lang] : translations.equipmentHeader[lang]}</button>
                ))}
              </div>
              <input className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6 outline-none focus:ring-2 focus:ring-blue-500" value={newTagName} onChange={e => setNewTagName(e.target.value)} placeholder={translations.tagNamePlaceholder[lang]} />
              <button onClick={() => { if (!newTagName) return; const t = { id: Date.now().toString(), name: newTagName, category: newTagCategory }; setCustomTags(p => { const u = [...p, t]; localStorage.setItem('fitlog_custom_tags', JSON.stringify(u)); return u; }); setShowAddTagModal(false); setNewTagName(''); }} className="w-full bg-blue-600 py-4 rounded-2xl font-black shadow-lg shadow-blue-600/20 active:scale-95 transition-all">{translations.confirm[lang]}</button>
           </div>
        </div>
      )}

      {showRenameModal && (
        <div className="fixed inset-0 z-[75] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-sm rounded-[2rem] p-8 space-y-6 shadow-2xl">
              <h2 className="text-xl font-black">{translations.editTags[lang]}</h2>
              <input className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6 outline-none focus:ring-2 focus:ring-blue-500" value={newTagNameInput} onChange={e => setNewTagNameInput(e.target.value)} placeholder={tagToRename?.name} />
              <div className="flex gap-4">
                <button onClick={() => setShowRenameModal(false)} className="flex-1 bg-slate-800 py-4 rounded-2xl font-black text-slate-400">{lang === Language.CN ? '取消' : 'Cancel'}</button>
                <button onClick={handleRenameTag} className="flex-1 bg-blue-600 py-4 rounded-2xl font-black">{translations.confirm[lang]}</button>
              </div>
           </div>
        </div>
      )}

      {showRenameExerciseModal && (
        <div className="fixed inset-0 z-[75] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-sm rounded-[2rem] p-8 space-y-6 shadow-2xl">
              <h2 className="text-xl font-black">{translations.editTags[lang]}</h2>
              <input className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6 outline-none focus:ring-2 focus:ring-blue-500" value={newExerciseNameInput} onChange={e => setNewExerciseNameInput(e.target.value)} placeholder={exerciseToRename?.name} />
              <div className="flex gap-4">
                <button onClick={() => setShowRenameExerciseModal(false)} className="flex-1 bg-slate-800 py-4 rounded-2xl font-black text-slate-400">{lang === Language.CN ? '取消' : 'Cancel'}</button>
                <button onClick={handleRenameExercise} className="flex-1 bg-blue-600 py-4 rounded-2xl font-black">{translations.confirm[lang]}</button>
              </div>
           </div>
        </div>
      )}

      {showAddExerciseModal && (
        <div className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-md rounded-[2.5rem] p-8 space-y-6 shadow-2xl overflow-y-auto max-h-[90vh] custom-scrollbar">
              <div className="flex justify-between items-center mb-2"><h2 className="text-2xl font-black">{translations.addCustomExercise[lang]}</h2><button onClick={() => setShowAddExerciseModal(false)} className="p-2 hover:bg-slate-800 rounded-full transition-colors"><X size={20}/></button></div>
              <div className="space-y-4">
                 <input className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6 outline-none focus:ring-2 focus:ring-blue-500 transition-all" value={newExerciseName} onChange={e => setNewExerciseName(e.target.value)} placeholder={translations.exerciseNamePlaceholder[lang]} />
                 <div className="space-y-3">
                   <h3 className="text-xs font-black text-slate-500 uppercase flex items-center gap-2"><Activity size={14} className="text-blue-500" />{translations.bodyPartHeader[lang]}</h3>
                   <div className="flex flex-wrap gap-2">{BODY_PARTS.map(id => (<button key={id} onClick={() => setNewExerciseBodyPart(id)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${newExerciseBodyPart === id ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`}>{getTagName(id)}</button>))}</div>
                 </div>
                 <div className="space-y-3">
                   <h3 className="text-xs font-black text-slate-500 uppercase flex items-center gap-2"><Dumbbell size={14} className="text-indigo-500" />{translations.equipmentHeader[lang]}</h3>
                   <div className="flex flex-wrap gap-2">{EQUIPMENT_TAGS.map(id => (<button key={id} onClick={() => setNewExerciseTags(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id])} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${newExerciseTags.includes(id) ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`}>{getTagName(id)}</button>))}</div>
                 </div>
              </div>
              <button onClick={() => { if (!newExerciseName) return; const ex: ExerciseDefinition = { id: Date.now().toString(), name: { en: newExerciseName, cn: newExerciseName }, bodyPart: newExerciseBodyPart, tags: newExerciseTags }; setCustomExercises(p => { const u = [...p, ex]; localStorage.setItem('fitlog_custom_exercises', JSON.stringify(u)); return u; }); setShowAddExerciseModal(false); setNewExerciseName(''); setNewExerciseTags([]); }} className="w-full bg-blue-600 py-5 rounded-3xl font-black text-lg shadow-xl shadow-blue-600/20 active:scale-95 transition-all">{translations.confirm[lang]}</button>
           </div>
        </div>
      )}

      {showLibrary && (
        <div className="fixed inset-0 z-[60] bg-slate-950/95 backdrop-blur-3xl p-6 flex flex-col animate-in fade-in">
          <div className="flex justify-between items-center mb-6"><h2 className="text-3xl font-black tracking-tight flex items-center gap-3"><Dumbbell className="text-blue-500" size={32} />{translations.selectExercise[lang]}</h2><button onClick={() => setShowLibrary(false)} className="p-3 bg-slate-800/50 hover:bg-slate-800 rounded-full transition-all border border-slate-700/50"><X size={24} /></button></div>
          <div className="relative mb-8"><Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500" size={20} /><input className="w-full bg-slate-900 border border-slate-800 rounded-[2rem] py-5 pl-14 pr-8 text-lg font-medium outline-none focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500/50 transition-all" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder={translations.searchPlaceholder[lang]} /></div>
          <div className="flex flex-1 overflow-hidden gap-4">
            <div onDragOver={(e) => { e.preventDefault(); setIsDraggingOverSidebar(true); }} onDragLeave={() => setIsDraggingOverSidebar(false)} onDrop={() => { if (draggedFromExId && draggedTagId) handleRemoveTagFromExercise(draggedFromExId, draggedTagId); setIsDraggingOverSidebar(false); setDraggedFromExId(null); setDraggedTagId(null); }} className={`w-1/3 lg:w-1/3 overflow-y-auto space-y-10 pr-4 border-r border-slate-800/50 custom-scrollbar transition-all ${isDraggingOverSidebar ? 'bg-red-500/10 border-r-red-500/50' : ''}`}>
              <button onClick={() => setSelectedTags([])} className={`w-full text-left px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${selectedTags.length === 0 ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-500 hover:bg-slate-800'}`}>{translations.allTags[lang]}</button>
              <div className="space-y-4">
                <div className="flex justify-between items-center px-2"><h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2"><Activity size={12} /> {translations.bodyPartHeader[lang]}</h3><button onClick={() => setIsEditingTags(!isEditingTags)} className="text-[10px] font-black uppercase text-blue-500 hover:text-blue-400">{isEditingTags ? translations.finishEdit[lang] : translations.editTags[lang]}</button></div>
                <div className="space-y-1.5">{BODY_PARTS.map(id => (<div key={id} className="relative group"><button draggable onDragStart={() => { setDraggedTagId(id); setDraggedFromExId(null); }} onClick={() => { if (isEditingTags) { setTagToRename({ id, name: getTagName(id) }); setNewTagNameInput(getTagName(id)); setShowRenameModal(true); } else { // 修改后：部位单选逻辑
                  setSelectedTags(p => {
                    // 先滤掉当前选中的所有部位标签（系统+自定义）
                    const withoutBodyParts = p.filter(tag => 
                      !BODY_PARTS.includes(tag) && 
                      !customTags.some(ct => ct.id === tag && ct.category === 'bodyPart')
                    );
                    // 如果点的是已选中的，则取消选择；如果点的是新的，则替换
                    return p.includes(id) ? withoutBodyParts : [...withoutBodyParts, id];}); } }} className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all ${selectedTags.includes(id) ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'} ${isEditingTags ? 'pr-10' : ''}`}>{getTagName(id)}</button>{isEditingTags && <PencilLine size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />}</div>))}
                                      {customTags.filter(ct => ct.category === 'bodyPart').map(ct => (<div key={ct.id} className="relative group"><button draggable onDragStart={() => { setDraggedTagId(ct.id); setDraggedFromExId(null); }} onClick={() => { if (isEditingTags) { setTagToRename({ id: ct.id, name: getTagName(ct.id) }); setNewTagNameInput(getTagName(ct.id)); setShowRenameModal(true); } else { setSelectedTags(p => {
                      const withoutBodyParts = p.filter(tag => 
                        !BODY_PARTS.includes(tag) && 
                        !customTags.some(ct => ct.id === tag && ct.category === 'bodyPart')
                      );
                      return p.includes(ct.id) ? withoutBodyParts : [...withoutBodyParts, ct.id];}); } }} className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all ${selectedTags.includes(ct.id) ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-800'} ${isEditingTags ? 'pr-14' : ''}`}>{getTagName(ct.id)}</button>{isEditingTags && (<div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1"><PencilLine size={14} className="text-slate-500" /><button onClick={(e) => { e.stopPropagation(); handleDeleteTag(ct.id); }} className="p-1 text-red-500 hover:bg-red-500/10 rounded-md"><Trash2 size={12} /></button></div>)}</div>))}
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] px-2 flex items-center gap-2"><Filter size={12} /> {translations.equipmentHeader[lang]}</h3>
                <div className="space-y-1.5">{EQUIPMENT_TAGS.map(id => (<div key={id} className="relative group"><button draggable onDragStart={() => { setDraggedTagId(id); setDraggedFromExId(null); }} onClick={() => { if (isEditingTags) { setTagToRename({ id, name: getTagName(id) }); setNewTagNameInput(getTagName(id)); setShowRenameModal(true); } else { setSelectedTags(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]); } }} className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all ${selectedTags.includes(id) ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'} ${isEditingTags ? 'pr-10' : ''}`}>{getTagName(id)}</button>{isEditingTags && <PencilLine size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />}</div>))}
                  {customTags.filter(ct => ct.category === 'equipment').map(ct => (<div key={ct.id} className="relative group"><button draggable onDragStart={() => { setDraggedTagId(ct.id); setDraggedFromExId(null); }} onClick={() => { if (isEditingTags) { setTagToRename({ id: ct.id, name: getTagName(ct.id) }); setNewTagNameInput(getTagName(ct.id)); setShowRenameModal(true); } else { setSelectedTags(p => p.includes(ct.id) ? p.filter(x => x !== ct.id) : [...p, ct.id]); } }} className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all ${selectedTags.includes(ct.id) ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-800'} ${isEditingTags ? 'pr-14' : ''}`}>{getTagName(ct.id)}</button>{isEditingTags && (<div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1"><PencilLine size={14} className="text-slate-500" /><button onClick={(e) => { e.stopPropagation(); handleDeleteTag(ct.id); }} className="p-1 text-red-500 hover:bg-red-500/10 rounded-md"><Trash2 size={12} /></button></div>)}</div>))}
                </div>
              </div>
              <div className="pt-8 border-t border-slate-800 space-y-3"><button onClick={() => setShowAddTagModal(true)} className="w-full py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest text-blue-400 hover:bg-blue-400/10 transition-all border border-blue-400/20 flex items-center justify-center gap-2"><PlusCircle size={16} /> {translations.addCustomTag[lang]}</button><button onClick={() => setShowAddExerciseModal(true)} className="w-full py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:bg-indigo-400/10 transition-all border border-indigo-400/20 flex items-center justify-center gap-2"><Zap size={16} /> {translations.addCustomExercise[lang]}</button></div>
            </div>
            <div className="flex-1 overflow-y-auto space-y-4 custom-scrollbar pr-2 pb-20">{filteredExercises.length === 0 ? (<div className="h-full flex flex-col items-center justify-center opacity-20 gap-4"><Search size={64} /><p className="font-black text-xl">{translations.noRecords[lang]}</p></div>) : (filteredExercises.map(ex => (<div key={ex.id} onDragOver={(e) => e.preventDefault()} onDrop={(e) => handleDropOnExercise(e, ex.id)} className="relative"><button onClick={() => { if (isEditingTags) { setExerciseToRename({ id: ex.id, name: ex.name[lang] }); setNewExerciseNameInput(ex.name[lang]); setShowRenameExerciseModal(true); return; } setCurrentWorkout(p => ({ ...p, exercises: [...(p.exercises || []), { id: Date.now().toString(), name: ex.name[lang], category: 'STRENGTH', sets: [{ id: Date.now().toString(), weight: 0, reps: 0, bodyweightMode: 'normal' }] }] })); setShowLibrary(false); }} className="w-full p-6 bg-slate-800/30 border border-slate-700/50 rounded-[1.5rem] text-left hover:bg-slate-800 hover:border-blue-500/50 transition-all group relative overflow-hidden"><div className="absolute right-0 top-0 w-32 h-32 bg-blue-600/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity"></div><div className="flex flex-col gap-3 relative z-10"><div className="flex justify-between items-center"><span className="font-black text-xl group-hover:text-blue-400 transition-colors">{ex.name[lang]}</span>{isEditingTags && <PencilLine size={18} className="text-slate-500" />}</div><div className="flex flex-wrap gap-2"><span draggable onDragStart={() => { setDraggedTagId(ex.bodyPart); setDraggedFromExId(ex.id); }} className="text-[10px] font-black uppercase bg-slate-800/80 px-3 py-1.5 rounded-xl text-slate-400 border border-slate-700/50 hover:bg-red-500/20 cursor-move transition-colors">{getTagName(ex.bodyPart)}</span>{ex.tags.map(t => (<span draggable onDragStart={() => { setDraggedTagId(t); setDraggedFromExId(ex.id); }} key={t} className="text-[10px] font-black uppercase bg-indigo-600/10 px-3 py-1.5 rounded-xl text-indigo-400 border border-indigo-500/20 hover:bg-red-500/20 cursor-move transition-colors">{getTagName(t)}</span>))}</div></div></button></div>)))}</div>
          </div>
        </div>
      )}

      {showGoalModal && (
        <div className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-sm rounded-[2.5rem] p-8 space-y-6 shadow-2xl">
              <h2 className="text-2xl font-black">{translations.setGoal[lang]}</h2>
              <div className="space-y-4">
                 <div className="flex gap-2">{['weight', 'strength', 'frequency'].map(type => <button key={type} onClick={() => setNewGoal({...newGoal, type: type as GoalType})} className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase transition-all ${newGoal.type === type ? 'bg-blue-600' : 'bg-slate-800'}`}>{translations[`goal${type.charAt(0).toUpperCase() + type.slice(1)}`][lang]}</button>)}</div>
                 <input className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6" value={newGoal.label} onChange={e => setNewGoal({...newGoal, label: e.target.value})} placeholder={translations.goalLabelPlaceholder[lang]} />
                 <div className="grid grid-cols-2 gap-4">
                    <input type="number" className="bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6" placeholder={translations.current[lang]} value={newGoal.currentValue || ''} onChange={e => setNewGoal({...newGoal, currentValue: Number(e.target.value)})} />
                    <input type="number" className="bg-slate-800 border border-slate-700 rounded-2xl py-4 px-6" placeholder={translations.target[lang]} value={newGoal.targetValue || ''} onChange={e => setNewGoal({...newGoal, targetValue: Number(e.target.value)})} />
                 </div>
              </div>
              <button onClick={handleAddGoal} className="w-full bg-blue-600 py-5 rounded-2xl font-black">{translations.confirm[lang]}</button>
           </div>
        </div>
      )}

      <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3"><Dumbbell className="text-blue-500" /><h1 className="text-xl font-black tracking-tight">{translations.appTitle[lang]}</h1></div>
        <div className="flex items-center gap-4">{syncStatus === 'syncing' && <RefreshCw className="animate-spin text-blue-500" size={18} />}<button onClick={() => setShowSettings(!showSettings)}><SettingsIcon size={22} className="text-slate-500 hover:text-white transition-colors" /></button></div>
      </header>

      {showSettings && (
        <div className="fixed right-6 top-20 z-50 w-72 bg-slate-800 border border-slate-700 rounded-[2rem] p-8 shadow-2xl animate-in fade-in">
          <div className="flex justify-between items-center mb-6"><span className="text-xs font-black text-slate-500 uppercase tracking-widest">{translations.languageLabel[lang]}</span><button onClick={handleToggleLanguage} className="text-blue-500 font-black px-4 py-2 bg-slate-900 rounded-xl border border-slate-700">{lang === Language.CN ? 'EN' : '中文'}</button></div>
          <div className="flex justify-between items-center mb-10"><span className="text-xs font-black text-slate-500 uppercase tracking-widest">{translations.unitLabel[lang]}</span><button onClick={() => { const n = unit === 'kg' ? 'lbs' : 'kg'; setUnit(n); localStorage.setItem('fitlog_unit', n); setShowSettings(false); }} className="text-blue-500 font-black px-4 py-2 bg-slate-900 rounded-xl border border-slate-700 uppercase">{unit}</button></div>
          <button onClick={() => { supabase.auth.signOut(); setUser(null); setShowSettings(false); localStorage.removeItem('fitlog_current_user'); setWorkouts([]); setGoals([]); setWeightEntries([]); }} className="w-full text-red-500 font-black flex items-center justify-between p-4 bg-red-500/10 rounded-2xl border border-red-500/20"><LogOut size={18} /> {translations.logout[lang]}</button>
        </div>
      )}

      {!user ? (
        <div className="min-h-screen flex items-center justify-center p-6 bg-[#0f172a]">
          <div className="w-full max-w-md bg-slate-800/30 backdrop-blur-2xl rounded-[3rem] p-10 border border-slate-700/50 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
            <div className="flex flex-col items-center mb-8">
              <div className="bg-blue-600/20 p-5 rounded-3xl mb-6 shadow-inner"><Dumbbell className="w-12 h-12 text-blue-500" /></div>
              <h1 className="text-4xl font-black text-white tracking-tight">{translations.appTitle[lang]}</h1>
              <p className="text-slate-400 mt-2 font-medium">
                {authMode === 'login' ? translations.loginWelcome[lang] : translations.registerWelcome[lang]}
              </p>
            </div>

            {authError && <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-500 text-xs font-black flex items-center gap-3 animate-in slide-in-from-top-2"><div className="p-1 bg-red-500 text-white rounded-full"><X size={12} strokeWidth={4} /></div>{authError}</div>}

            <form onSubmit={handleAuth} className="space-y-4">
              {authMode === 'register' && (
                <div className="relative group">
                  <UserIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors" size={20} />
                  <input type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder={translations.username[lang]} className="w-full bg-slate-900 border border-slate-700 rounded-2xl py-4 pl-14 pr-6 text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all" required />
                </div>
              )}
              
              <div className="relative group">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors" size={20} />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder={translations.email[lang]} className="w-full bg-slate-900 border border-slate-700 rounded-2xl py-4 pl-14 pr-6 text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all" required />
              </div>

              <div className="relative group">
                <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors" size={20} />
                <input type={showPassword ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} placeholder={translations.password[lang]} className="w-full bg-slate-900 border border-slate-700 rounded-2xl py-4 pl-14 pr-16 text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all" required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors">{showPassword ? <EyeOff size={20} /> : <Eye size={20} />}</button>
              </div>

              <button type="submit" disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-500 text-white py-5 rounded-3xl font-black text-lg flex items-center justify-center gap-3 shadow-xl shadow-blue-600/20 active:scale-95 transition-all">
                {isLoading ? <RefreshCw className="animate-spin" /> : (authMode === 'register' ? translations.createAccount[lang] : translations.login[lang])}
              </button>
            </form>

            <div className="flex flex-col gap-4 mt-8">
              {authMode === 'login' ? (
                <button onClick={() => setAuthMode('register')} className="text-slate-500 text-xs font-bold hover:text-blue-400 transition-colors text-center">{translations.noAccount[lang]} <span className="text-blue-500">{translations.createAccount[lang]}</span></button>
              ) : (
                <button onClick={() => setAuthMode('login')} className="text-slate-500 text-xs font-bold hover:text-blue-400 transition-colors text-center">{translations.hasAccount[lang]} <span className="text-blue-500">{translations.login[lang]}</span></button>
              )}
            </div>

            <div className="flex items-center my-6"><div className="flex-1 h-[1px] bg-slate-800"></div><span className="px-4 text-[10px] font-black uppercase text-slate-700 tracking-widest">{translations.orSeparator[lang]}</span><div className="flex-1 h-[1px] bg-slate-800"></div></div>
            <button onClick={async () => { const u = {id: 'u_guest', username: 'Guest', email: 'guest@fitlog.ai'}; setUser(u); localStorage.setItem('fitlog_current_user', JSON.stringify(u)); await loadLocalData('u_guest'); }} className="w-full bg-slate-800/50 text-slate-300 py-4 rounded-3xl font-bold flex items-center justify-center gap-2 hover:bg-slate-700 transition-all active:scale-90"><Zap size={18} className="text-amber-400" /> {translations.quickLogin[lang]}</button>
          </div>
        </div>
      ) : (
        <main className="max-w-2xl mx-auto p-4 md:p-8">
          {activeTab === 'dashboard' && (<div className="space-y-6 animate-in fade-in">
            {workouts.length === 0 && weightEntries.length === 0 ? (
              <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6 animate-in slide-in-from-bottom-10">
                <div className="bg-blue-600/10 p-10 rounded-full border border-blue-500/20 mb-8 animate-pulse shadow-2xl shadow-blue-500/10"><Trophy size={80} className="text-blue-500" /></div>
                <h2 className="text-3xl font-black mb-4 bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">{translations.dashboardEmptyTitle[lang]}</h2>
                <p className="text-slate-400 max-w-sm font-medium leading-relaxed text-lg mb-10">{translations.dashboardEmptyDesc[lang]}</p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button onClick={() => setActiveTab('new')} className="group bg-blue-600 px-10 py-5 rounded-[2rem] font-black text-xl shadow-xl shadow-blue-600/30 active:scale-95 transition-all flex items-center gap-3"><PlusCircle size={24} className="group-hover:rotate-90 transition-transform" />{translations.newWorkout[lang]}</button>
                  <button onClick={() => setShowWeightInput(true)} className="bg-slate-800 px-10 py-5 rounded-[2rem] font-black text-xl shadow-xl active:scale-95 transition-all flex items-center gap-3"><Scale size={24} className="text-blue-500" />{translations.logWeight[lang]}</button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-gradient-to-br from-indigo-900/40 to-slate-800/40 rounded-[2.5rem] border border-indigo-500/20 p-8 shadow-xl">
                  <div className="flex justify-between items-center cursor-pointer" onClick={() => setSelectedPRProject(selectedPRProject === '__WEIGHT__' ? null : '__WEIGHT__')}>
                    <div className="flex flex-col">
                      <h3 className="text-xs font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2 mb-2"><Scale size={16} /> {translations.currentWeight[lang]}</h3>
                      <div className="flex items-end">
                        <span className="text-4xl font-black text-white">{weightEntries.length > 0 ? formatWeight(weightEntries[0].weight) : '--'}</span>
                        <span className="text-slate-500 font-bold ml-2 uppercase text-sm mb-1">{unit}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <button onClick={(e) => { e.stopPropagation(); setEditingWeightId(null); setWeightInputValue(''); setShowWeightInput(true); }} className="p-3 bg-indigo-600 rounded-2xl hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-600/20 active:scale-90"><Plus size={20} /></button>
                      <div className="p-2 text-slate-500">
                        {selectedPRProject === '__WEIGHT__' ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
                      </div>
                    </div>
                  </div>
                  {selectedPRProject === '__WEIGHT__' && (
                    <div className="border-t border-indigo-500/10 mt-6 pt-6">
                      <p className="text-[10px] text-indigo-400/60 font-black uppercase tracking-widest mb-4 flex items-center gap-2"><TrendingUp size={12} /> {translations.weightTrend[lang]}</p>
                      {renderTrendChart('__WEIGHT__')}
                      <div className="mt-8 space-y-4 max-h-[300px] overflow-y-auto custom-scrollbar pr-2 pt-2 border-t border-indigo-500/5">
                        <h4 className="text-[10px] text-slate-500 font-black uppercase tracking-widest flex items-center gap-2 mb-4 px-1">
                          <History size={12} /> {lang === Language.CN ? '历史体重记录' : 'Weight History'} ({weightEntries.length})
                        </h4>
                        {weightEntries.map(entry => (
                          <div key={entry.id} className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800/50 flex justify-between items-center">
                            <div className="flex items-center gap-4">
                              <button 
                                onClick={() => triggerEditWeight(entry)}
                                className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl hover:bg-indigo-500/20 transition-all active:scale-90"
                              >
                                <Edit2 size={12} />
                              </button>
                              <div>
                                <span className="text-sm font-black text-white">{formatWeight(entry.weight)}</span>
                                <span className="text-[10px] text-slate-500 font-bold uppercase ml-1">{unit}</span>
                              </div>
                            </div>
                            <span className="text-[10px] text-slate-600 font-bold">
                              {new Date(entry.date).toLocaleDateString(lang === Language.CN ? 'zh-CN' : 'en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <h3 className="text-xs font-black text-slate-500 uppercase flex items-center gap-2 px-2"><Trophy className="text-amber-500" size={16} /> {translations.prManagement[lang]}</h3>
                  {bestLifts.map(lift => {
                    const isExpanded = selectedPRProject === lift.name;
                    const isStarred = !!starredExercises[lift.name];
                    const historyExs = workouts
                      .flatMap(w => w.exercises.map(e => ({ ...e, date: w.date, workoutId: w.id })))
                      .filter(e => resolveName(e.name) === lift.name)
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

                    return (
                      <div key={lift.name} className={`bg-slate-800/40 rounded-[2.5rem] border border-slate-700/50 p-6 transition-all duration-300 hover:border-slate-600 shadow-lg ${isExpanded ? 'ring-2 ring-blue-500/20' : ''}`}>
                        <div className="flex justify-between items-center cursor-pointer" onClick={() => setSelectedPRProject(isExpanded ? null : lift.name)}>
                          <div className="flex items-center gap-4">
                            <button onClick={(e) => { e.stopPropagation(); toggleStarExercise(lift.name); }} className={`p-3 rounded-2xl transition-all ${isStarred ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20' : 'bg-slate-900 text-slate-600 hover:text-amber-500'}`}><Star size={20} fill={isStarred ? "currentColor" : "none"} /></button>
                            <span className="font-black text-slate-200">{lift.name}</span>
                          </div>
                          <div className="flex items-center gap-6">
                            <div className="text-right"><span className="block font-black text-white text-lg leading-none">{formatWeight(lift.weight)}</span><span className="text-[10px] font-bold text-slate-600 uppercase">{unit}</span></div>
                            <div className="text-slate-700">{isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}</div>
                          </div>
                        </div>
                        {isExpanded && (
                          <div className="border-t border-slate-700/30 mt-6 pt-6 overflow-hidden animate-in slide-in-from-top-4">
                            <div className="mb-8">{renderTrendChart(lift.name)}</div>
                            {historyExs.length > 0 && (
                              <div className="space-y-4 mt-4 border-t border-slate-800 pt-8">
                                <button onClick={() => setIsHistoryVisible(!isHistoryVisible)} className="w-full flex items-center justify-between px-1 group"><h4 className="text-[10px] text-slate-500 font-black uppercase tracking-widest group-hover:text-blue-400 transition-colors">{translations.history[lang]} ({historyExs.length})</h4><div className={`p-2 rounded-xl bg-slate-900/50 text-slate-600 group-hover:text-blue-500 transition-all ${isHistoryVisible ? 'rotate-180 text-blue-500' : ''}`}><ChevronDown size={16} /></div></button>
                                {isHistoryVisible && (
                                  <div className="space-y-6 max-h-[500px] overflow-y-auto custom-scrollbar pr-2 pt-2 animate-in fade-in slide-in-from-top-2">
                                    {historyExs.map((ex, exIdx) => (
                                      <div key={`${ex.workoutId}-${ex.id}-${exIdx}`} className="space-y-4 pb-6 border-b border-slate-800/30 last:border-0 last:pb-0">
                                        <div className="flex justify-between items-center px-1">
                                          <div className="flex items-center gap-3">
                                            <button onClick={(e) => { e.stopPropagation(); handleEditWorkout(ex.workoutId); }} className="p-2 bg-blue-500/10 text-blue-500 rounded-xl hover:bg-blue-500/20 transition-all active:scale-90"><Edit2 size={14} /></button>
                                            <div className="flex items-center gap-2"><Calendar size={14} className="text-slate-600" /><span className="text-[11px] text-slate-400 font-bold">{new Date(ex.date).toLocaleDateString(lang === Language.CN ? 'zh-CN' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric' })}</span></div>
                                          </div>
                                          <span className="text-[10px] font-black bg-slate-800/80 text-slate-500 px-3 py-1 rounded-full uppercase tracking-wider border border-slate-700/30">{ex.sets.length} {translations.setsCount[lang]}</span>
                                        </div>
                                        <div className="flex flex-wrap gap-2">{ex.sets.map((s: any, si: number) => renderSetCapsule(s, si))}</div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>)}

          {activeTab === 'new' && (<div className="space-y-8 animate-in slide-in-from-bottom-5"><div className="bg-slate-800/40 p-8 rounded-[2.5rem] border border-slate-700/50"><input className="bg-transparent text-3xl font-black w-full outline-none" value={currentWorkout.title} onChange={e => setCurrentWorkout({...currentWorkout, title: e.target.value})} placeholder={translations.trainingTitlePlaceholder[lang]} /></div><div className="space-y-6">{currentWorkout.exercises?.map((ex, exIdx) => { 
            const isBodyweight = isBodyweightExercise(ex.name); 
            const isPyramid = isPyramidExercise(ex.name);
            return (<div key={ex.id} className="bg-slate-800/40 p-8 rounded-[2.5rem] border border-slate-700/50"><div className="flex justify-between items-center mb-6"><h3 className="text-xl font-black text-blue-400">{resolveName(ex.name)}</h3><button onClick={() => setCurrentWorkout({...currentWorkout, exercises: currentWorkout.exercises!.filter((_, i) => i !== exIdx)})} className="text-slate-600 hover:text-red-500 transition-colors"><Trash2 size={20} /></button></div>{isBodyweight && (<div className="flex gap-2 mb-6 p-1 bg-slate-900 rounded-2xl border border-slate-800">{(['normal', 'weighted', 'assisted'] as BodyweightMode[]).map(mode => (<button key={mode} onClick={() => { const exs = [...currentWorkout.exercises!]; exs[exIdx].sets = exs[exIdx].sets.map(s => ({ ...s, bodyweightMode: mode })); setCurrentWorkout({...currentWorkout, exercises: exs}); }} className={`flex-1 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${ex.sets[0]?.bodyweightMode === mode ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-600'}`}>{translations[`mode${mode.charAt(0).toUpperCase() + mode.slice(1)}` as keyof typeof translations][lang]}</button>))}</div>)}<div className="grid grid-cols-4 gap-4 items-center px-4 mb-3 text-[10px] font-black uppercase text-slate-500 tracking-widest"><span className="pl-2">{translations.sets[lang]}</span><span className="text-center">{translations.weight[lang]} ({unit})</span><span className="text-center">{translations.reps[lang]}</span><span className="text-right"></span></div><div className="space-y-4">{ex.sets.map((set, setIdx) => (<div key={set.id} className="space-y-2">
              <div className="grid grid-cols-4 gap-4 items-center bg-slate-900 p-4 rounded-2xl border border-slate-800 transition-all focus-within:border-blue-500/50">
                <span className="text-blue-500 font-black pl-2">{setIdx + 1}</span>
                <input type="number" step="any" className="bg-transparent font-bold text-center outline-none text-white focus:text-blue-400 w-full" value={set.weight === 0 ? '' : (unit === 'kg' ? set.weight : parseFloat((set.weight * KG_TO_LBS).toFixed(2)))} placeholder="0" onChange={e => { const val = e.target.value === '' ? 0 : Number(e.target.value); const exs = [...currentWorkout.exercises!]; exs[exIdx].sets[setIdx].weight = parseWeight(val); setCurrentWorkout({...currentWorkout, exercises: exs}); }} />
                <input type="number" className="bg-transparent font-bold text-center outline-none text-white focus:text-blue-400" value={set.reps || ''} placeholder="0" onChange={e => { const val = e.target.value === '' ? 0 : Number(e.target.value); const exs = [...currentWorkout.exercises!]; exs[exIdx].sets[setIdx].reps = val; setCurrentWorkout({...currentWorkout, exercises: exs}); }} />
                <div className="flex justify-end gap-2 pr-2">
                  {isPyramid && (
                    <button onClick={() => {
                      const exs = [...currentWorkout.exercises!];
                      const s = exs[exIdx].sets[setIdx];
                      s.subSets = [...(s.subSets || []), { weight: s.weight, reps: s.reps }];
                      setCurrentWorkout({...currentWorkout, exercises: exs});
                    }} className="text-indigo-400 hover:text-indigo-300 transition-colors" 
                       title={lang === Language.CN ? "添加递减组" : "Add Drop Set"}>
                      <Layers size={18} />
                    </button>
                  )}
                  <button onClick={() => { const exs = [...currentWorkout.exercises!]; exs[exIdx].sets = exs[exIdx].sets.filter((_, i) => i !== setIdx); setCurrentWorkout({...currentWorkout, exercises: exs}); }} className="text-slate-600 hover:text-red-500"><Minus size={18} /></button>
                </div>
              </div>
              {isPyramid && set.subSets && set.subSets.map((sub, ssi) => (
                <div key={ssi} className="grid grid-cols-4 gap-4 items-center bg-slate-900/40 ml-8 p-3 rounded-xl border border-dashed border-slate-800 animate-in slide-in-from-left-2">
                  {/* 修改：根据语言显示子组前缀 */}
                  <span className="text-[10px] font-black text-slate-600 uppercase">
                    {lang === Language.CN ? '递减' : 'Sub'}
                  </span>
                  <input type="number" step="any" className="bg-transparent text-sm font-bold text-center outline-none text-slate-300 w-full" value={sub.weight === 0 ? '' : (unit === 'kg' ? sub.weight : parseFloat((sub.weight * KG_TO_LBS).toFixed(2)))} onChange={e => {
                    const val = e.target.value === '' ? 0 : Number(e.target.value);
                    const exs = [...currentWorkout.exercises!];
                    exs[exIdx].sets[setIdx].subSets![ssi].weight = parseWeight(val);
                    setCurrentWorkout({...currentWorkout, exercises: exs});
                  }} />
                  <input type="number" className="bg-transparent text-sm font-bold text-center outline-none text-slate-300" value={sub.reps || ''} onChange={e => {
                    const val = e.target.value === '' ? 0 : Number(e.target.value);
                    const exs = [...currentWorkout.exercises!];
                    exs[exIdx].sets[setIdx].subSets![ssi].reps = val;
                    setCurrentWorkout({...currentWorkout, exercises: exs});
                  }} />
                  <button onClick={() => {
                    const exs = [...currentWorkout.exercises!];
                    exs[exIdx].sets[setIdx].subSets = exs[exIdx].sets[setIdx].subSets!.filter((_, i) => i !== ssi);
                    setCurrentWorkout({...currentWorkout, exercises: exs});
                  }} className="flex justify-end pr-2 text-slate-700 hover:text-red-500">
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>))}</div><button onClick={() => { const exs = [...currentWorkout.exercises!]; const currentSets = exs[exIdx].sets; const lastSet = currentSets.length > 0 ? currentSets[currentSets.length - 1] : null; exs[exIdx].sets.push({ id: Date.now().toString(), weight: lastSet ? lastSet.weight : 0, reps: lastSet ? lastSet.reps : 0, bodyweightMode: lastSet ? lastSet.bodyweightMode : (isBodyweight ? 'normal' : undefined) }); setCurrentWorkout({...currentWorkout, exercises: exs}); }} className="w-full mt-4 py-3 border border-dashed border-slate-700 rounded-xl text-slate-500 font-black flex items-center justify-center gap-2 hover:bg-slate-800/50 transition-colors"><Plus size={16} /> {translations.addSet[lang]}</button></div>); })}</div><div className="flex gap-4"><button onClick={() => setShowLibrary(true)} className="flex-1 bg-slate-800/80 p-5 rounded-3xl font-black flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors"><PlusCircle /> {translations.addExercise[lang]}</button><button onClick={handleSaveWorkout} className="flex-1 bg-blue-600 p-5 rounded-3xl font-black shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 hover:bg-blue-500 active:scale-95 transition-all"><Check /> {translations.saveWorkout[lang]}</button></div></div>)}

          {activeTab === 'goals' && (<div className="space-y-6 animate-in slide-in-from-right"><div className="flex justify-between items-center"><div><h2 className="text-3xl font-black">{translations.goals[lang]}</h2><p className="text-slate-500">{translations.goalsSubtitle[lang]}</p></div><button onClick={() => setShowGoalModal(true)} className="p-4 bg-blue-600 rounded-2xl"><Plus size={24} /></button></div><div className="grid grid-cols-1 md:grid-cols-2 gap-6">{goals.map(g => (<div key={g.id} className="bg-slate-800/40 p-8 rounded-[2.5rem] border border-slate-700/50"><div className="flex justify-between items-start mb-4"><div><h4 className="font-black text-xl">{g.label}</h4><span className="text-[10px] text-blue-500 uppercase">{g.type}</span></div><button onClick={async () => { await db.delete('goals', g.id); setGoals(p => p.filter(x => x.id !== g.id)); }}><Trash2 size={16} className="text-slate-700" /></button></div><div className="flex justify-between items-end mb-2"><span className="text-2xl font-black">{g.currentValue} / {g.targetValue}</span><span className="text-slate-500 text-xs">{g.unit}</span></div><div className="h-2 bg-slate-900 rounded-full overflow-hidden"><div className="h-full bg-blue-600" style={{ width: `${Math.min(100, (g.currentValue / g.targetValue) * 100)}%` }}></div></div></div>))}</div></div>)}
        </main>
      )}

      {user && (
        <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md bg-slate-950/90 backdrop-blur-3xl border border-white/10 p-4 flex justify-between items-center rounded-[3rem] z-50">
          <button onClick={() => setActiveTab('dashboard')} className={`flex-1 flex flex-col items-center gap-1 ${activeTab === 'dashboard' ? 'text-blue-500' : 'text-slate-600'}`}><BarChart2 size={24} /><span className="text-[8px] font-black uppercase">{translations.dashboard[lang]}</span></button>
          <button onClick={() => setActiveTab('goals')} className={`flex-1 flex flex-col items-center gap-1 ${activeTab === 'goals' ? 'text-blue-500' : 'text-slate-600'}`}><Target size={24} /><span className="text-[8px] font-black uppercase">{translations.goals[lang]}</span></button>
          <div className="flex-1 flex justify-center"><button onClick={() => { setCurrentWorkout({ title: '', exercises: [], date: new Date().toISOString() }); setActiveTab('new'); }} className="p-4 bg-blue-600 rounded-full -mt-12 border-8 border-slate-900 shadow-2xl transition-all active:scale-90"><Plus size={32} /></button></div>
        </nav>
      )}
    </div>
  );
};

export default App;